<?php
    // site key & secret key configuration for google recaptcha
    $dataKey = "6Ld4FF4UAAAAAHAAeSN1Cto5Wk8gVbHDv90hBJcm";
    $secretKey = "6Ld4FF4UAAAAAA5Z06Z3qA054GoGxEFs_KNl9lct";
    // your bank account number and additional information used by customer to pay for your products
    $bankaccountnumber = array(
        "50 1020 5558 1111 1389 1450 0019", // account number
        "Piotr Kurnicki",
        "50-539 Wrocław",
        "Jabłeczna 26/26"
    );
    
    // database configuration
    define('DB_SERVER', 'localhost');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', '');
    define('DB_DATABASE', 'cart');
    $conn = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>